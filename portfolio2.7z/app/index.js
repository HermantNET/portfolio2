import calculator from './calculator';
import gallery from './gallery';
import t3 from './tictactoe';

import styles from './styles/styles.css';
import css_calculator from './styles/calculator.css';
import css_gallery from './styles/gallery.css';
import css_t3 from './styles/t3.css';
